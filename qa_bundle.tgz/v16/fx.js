const { chromium } = require('/usr/local/lib/node_modules/playwright');
(async () => { const b = await chromium.launch(); const errs = [];
  for (const [w, h, n] of [[1440, 900, 'd'], [390, 844, 'm']]) { const p = await b.newPage({ viewport: { width: w, height: h } }); p.on('pageerror', e => errs.push(e.message));
    await p.goto('http://localhost:8788/', { waitUntil: 'load' }); for (const t of [400, 1600, 3200]) { await p.waitForTimeout(t === 400 ? 400 : t - 400); await p.screenshot({ path: `v16/fx_${n}_${t}.jpg`, quality: 55, type: 'jpeg', clip: { x: 0, y: 0, width: w, height: Math.min(h, 620) } }); }
    await p.evaluate(() => document.querySelector('#gioi-thieu').scrollIntoView()); await p.waitForTimeout(1500); await p.screenshot({ path: `v16/fx_${n}_sec.jpg`, quality: 55, type: 'jpeg' }); await p.close(); }
  console.log(JSON.stringify(errs)); await b.close(); })();
