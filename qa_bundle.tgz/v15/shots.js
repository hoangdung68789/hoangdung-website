const { chromium } = require(require('child_process').execSync('npm root -g').toString().trim() + '/playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const run = async (w, h, theme, name, secs) => {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, colorScheme: theme === 'dark' ? 'dark' : 'light', reducedMotion: 'reduce' });
    const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(name + ' PE ' + e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(name + ' ' + m.text()); });
    await p.goto('http://localhost:8788/', { waitUntil: 'networkidle' }); await p.waitForTimeout(800);
    for (const [sel, tag] of secs) {
      if (sel === 'top') await p.evaluate(() => scrollTo(0, 0)); else await p.evaluate(s => { const el = document.querySelector(s); scrollTo(0, el.getBoundingClientRect().top + scrollY - 80); }, sel);
      await p.waitForTimeout(500); await p.screenshot({ path: `v15/${name}_${tag}.jpg`, quality: 60, type: 'jpeg' });
    }
    const ov = await p.evaluate(() => document.documentElement.scrollWidth - innerWidth); if (ov > 0) errs.push(name + ' overflow-x ' + ov);
    await ctx.close();
  };
  const S = [['top', 'top'], ['#dich-vu .svc', 'svc'], ['#tinh-vay', 'calc'], ['#phap-ly', 'legal'], ['#giant', 'foot']];
  await run(1536, 864, 'light', 'd1536L', S);
  await run(1536, 864, 'dark', 'd1536D', S);
  await run(1920, 1080, 'light', 'd1920L', [['top', 'top'], ['#giant', 'foot']]);
  await run(390, 844, 'light', 'm390L', [['top', 'top'], ['#phap-ly', 'legal']]);
  await run(390, 844, 'dark', 'm390D', [['top', 'top'], ['#tinh-vay', 'calc'], ['#phap-ly', 'legal']]);
  await run(320, 640, 'light', 'm320L', [['top', 'top']]);
  await run(1180, 800, 'light', 'd1180L', [['top', 'top']]);
  console.log(JSON.stringify(errs, null, 1)); await b.close();
})();
